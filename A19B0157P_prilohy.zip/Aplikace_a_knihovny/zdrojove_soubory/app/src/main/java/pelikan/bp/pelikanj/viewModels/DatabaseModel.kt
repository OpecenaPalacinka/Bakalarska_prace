package pelikan.bp.pelikanj.viewModels

data class DatabaseModel(
    var language: String?,
    var token: String?,
    var profilePicture: String?
)
