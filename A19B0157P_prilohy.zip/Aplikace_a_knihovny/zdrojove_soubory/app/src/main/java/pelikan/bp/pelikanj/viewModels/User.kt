package pelikan.bp.pelikanj.viewModels

data class User(
        val username: String,
        val password: String,
        val email: String
)
