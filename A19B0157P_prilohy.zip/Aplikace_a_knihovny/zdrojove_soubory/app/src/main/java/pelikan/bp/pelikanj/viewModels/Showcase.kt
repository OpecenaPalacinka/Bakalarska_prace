package pelikan.bp.pelikanj.viewModels

data class Showcase(
    val showcaseId: Int,
    val name: String,
    val description: String,
    val roomId: Int,
    val createdAt: String
)