package pelikan.bp.pelikanj.viewModels

data class TokenModel(
    val token: String
)