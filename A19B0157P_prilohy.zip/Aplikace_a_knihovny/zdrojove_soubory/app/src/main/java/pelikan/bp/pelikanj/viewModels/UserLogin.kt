package pelikan.bp.pelikanj.viewModels

data class UserLogin(
    val username: String,
    val password: String
)
