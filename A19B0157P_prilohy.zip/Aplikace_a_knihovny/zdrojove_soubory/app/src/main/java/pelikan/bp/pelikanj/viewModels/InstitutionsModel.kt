package pelikan.bp.pelikanj.viewModels

class InstitutionsModel : ArrayList<InstitutionsModelItem>()