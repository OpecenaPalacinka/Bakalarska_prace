package pelikan.bp.pelikanj.viewModels

data class PasswordModel(
    val password: String
)
