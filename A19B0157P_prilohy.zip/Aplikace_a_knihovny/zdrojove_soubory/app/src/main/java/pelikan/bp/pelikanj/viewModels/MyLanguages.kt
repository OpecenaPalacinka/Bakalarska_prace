package pelikan.bp.pelikanj.viewModels

class MyLanguages(var language: String, var languageShort: String)