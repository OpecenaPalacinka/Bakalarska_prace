package pelikan.bp.pelikanj.ui.more.languageSetting

class MyLanguages(var language: String, var languageShort: String)