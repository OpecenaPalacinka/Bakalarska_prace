package pelikan.bp.pelikanj.viewModels

data class Building(
    val buildingId: Int,
    val name: String,
    val description: String,
    val institutionId: Int,
    val createdAt: String
)