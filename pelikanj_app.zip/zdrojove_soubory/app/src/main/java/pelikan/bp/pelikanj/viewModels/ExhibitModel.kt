package pelikan.bp.pelikanj.viewModels

class ExhibitModel : ArrayList<ExhibitModelItem>()